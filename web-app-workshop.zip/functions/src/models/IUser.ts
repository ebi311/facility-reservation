export interface IUser {
  displayName: string;
  email: string;
  face?: string;
}
